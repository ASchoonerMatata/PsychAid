#!/bin/bash
cd "$(dirname "$0")"
lsof -ti :5050 | xargs kill -9 2>/dev/null; sleep 0.5
echo "Installing/checking dependencies..."
python3 -m pip install flask reportlab pypdf anthropic python-docx mammoth --quiet --break-system-packages 2>&1 | tail -5
echo "Starting PsychAid..."
python3 app.py &
FLASK_PID=$!
echo "Waiting for server..."
for i in {1..20}; do
    sleep 1
    if curl -s http://127.0.0.1:5050 > /dev/null 2>&1; then
        echo "Server ready!"
        break
    fi
done
open http://127.0.0.1:5050
wait $FLASK_PID
