@echo off
title PsychAid
cd /d "%~dp0"

echo == PsychAid ==
echo Installing dependencies...

pip install flask reportlab pypdf anthropic python-docx mammoth pywebview --quiet
if %errorlevel% neq 0 (
    echo ERROR: pip failed. Make sure Python 3 is installed from python.org
    pause
    exit /b 1
)

echo Starting PsychAid...
python main.py
