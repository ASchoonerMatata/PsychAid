#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "=== PsychAid Mac Builder ==="
echo "Installing build dependencies..."
pip3 install pyinstaller --break-system-packages 2>/dev/null || pip3 install pyinstaller
pip3 install flask reportlab pypdf anthropic python-docx mammoth --break-system-packages 2>/dev/null || true

echo "Building Mac app bundle..."
pyinstaller --clean --noconfirm --windowed --name PsychAid \
  --add-data "templates:templates" \
  --add-data "static:static" \
  --hidden-import flask \
  --hidden-import jinja2 \
  --hidden-import jinja2.ext \
  --hidden-import werkzeug \
  --hidden-import werkzeug.serving \
  --hidden-import werkzeug.routing \
  --hidden-import werkzeug.exceptions \
  --hidden-import werkzeug.middleware \
  --hidden-import click \
  --hidden-import anthropic \
  --hidden-import anthropic._models \
  --hidden-import pypdf \
  --hidden-import pypdf._reader \
  --hidden-import mammoth \
  --hidden-import docx \
  --hidden-import docx.oxml \
  --hidden-import reportlab \
  --hidden-import reportlab.pdfgen \
  --hidden-import reportlab.pdfgen.canvas \
  --hidden-import reportlab.lib \
  --hidden-import reportlab.lib.pagesizes \
  --hidden-import reportlab.lib.units \
  main.py

echo ""
echo "=== Build complete! ==="
echo "App bundle: dist/PsychAid.app"
echo "Opening dist/ folder..."
open dist/
