@echo off
title PsychAid Builder
cd /d "%~dp0"

echo === PsychAid Windows Builder ===
echo Installing PyInstaller and dependencies...

pip install pyinstaller flask reportlab pypdf anthropic python-docx mammoth pywebview

echo.
echo Building standalone executable...
pyinstaller --clean --noconfirm --windowed --name PsychAid ^
  --add-data "templates;templates" ^
  --add-data "static;static" ^
  --hidden-import flask ^
  --hidden-import jinja2 ^
  --hidden-import jinja2.ext ^
  --hidden-import werkzeug ^
  --hidden-import werkzeug.serving ^
  --hidden-import werkzeug.routing ^
  --hidden-import werkzeug.exceptions ^
  --hidden-import click ^
  --hidden-import anthropic ^
  --hidden-import pypdf ^
  --hidden-import mammoth ^
  --hidden-import docx ^
  --hidden-import docx.oxml ^
  --hidden-import reportlab ^
  --hidden-import reportlab.pdfgen ^
  --hidden-import reportlab.pdfgen.canvas ^
  --hidden-import reportlab.lib ^
  --hidden-import reportlab.lib.pagesizes ^
  main.py

echo.
echo === Build complete! ===
echo Your app is in: dist\PsychAid\PsychAid.exe
explorer dist\PsychAid
pause
